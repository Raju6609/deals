<?php 
error_reporting(0);
include('admin/config/connection.php');

$getcontent->get_content();

?>

