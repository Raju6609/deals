<?php
define('YOUR_CONSUMER_KEY', 'dH8nvXsQymfcNplortDNsWG7f');
define('YOUR_CONSUMER_SECRET', 'g5LydcMPzLTzcO2clxNUOxWt0klSWMgHsertk4bYn9kAMll5Bf');
?>
