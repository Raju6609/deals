<div class="conty_bg">
<div class="inner">
<div id="layout">
	<ul class="breadcrumb">
    	<li><a href="./">Home</a></li>
        <li>Privacy Policy</li>
    </ul>
    <div class="row">
    	<h2 class="heading">Privacy Policy</h2>
        <h3 class="sm-heading">Pellentesque sed dolor. Aliquam congue fermentum nisl. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pel lentesque vitae turpis tristique, feugiat nisl eget, pellentesque ipsum. Proin ullamcorper laoreet erat ac convall is.</h3>
        <p class="hero-text">Pellentesque sed dolor. Aliquam congue fermentum nisl. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pel lentesque vitae turpis tristique, feugiat nisl eget, pellentesque ipsum. Proin ullamcorper.Pellentesque sed dolor. Aliquam congue fermentum nisl. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pel lentesque vitae turpis tristique, feugiat nisl eget, pellentesque ipsum. Proin ullamcorper laoreet erat ac convall is. Cras sodales justo sit amet leo pellentesque, non porta mi aliquet. Nulla laoreet et metus a posuere ntege eget ante ferm entum, accumsan odio nec, feugiat sem. Nullam venenatis auctor neque</p>  
    </div>
      <div class="row">
        <h3 class="sm-heading">Pellentesque sed dolor. Aliquam congue fermentum nisl. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pel lentesque vitae turpis tristique, feugiat nisl eget, pellentesque ipsum. Proin ullamcorper laoreet erat ac convall is.</h3>
        <p class="hero-text">Pellentesque sed dolor. Aliquam congue fermentum nisl. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pel lentesque vitae turpis tristique, feugiat nisl eget, pellentesque ipsum. Proin ullamcorper.Pellentesque sed dolor. Aliquam congue fermentum nisl. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pel lentesque vitae turpis tristique, feugiat nisl eget, pellentesque ipsum. Proin ullamcorper laoreet erat ac convall is. Cras sodales justo sit amet leo pellentesque, non porta mi aliquet. Nulla laoreet et metus a posuere ntege eget ante ferm entum, accumsan odio nec, feugiat sem. Nullam venenatis auctor neque</p>  
    </div>
          <div class="row">
        <h3 class="sm-heading">Pellentesque sed dolor. Aliquam congue fermentum nisl. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pel lentesque vitae turpis tristique, feugiat nisl eget, pellentesque ipsum. Proin ullamcorper laoreet erat ac convall is.</h3>
        <p class="hero-text">Pellentesque sed dolor. Aliquam congue fermentum nisl. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pel lentesque vitae turpis tristique, feugiat nisl eget, pellentesque ipsum. Proin ullamcorper.Pellentesque sed dolor. Aliquam congue fermentum nisl. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pel lentesque vitae turpis tristique, feugiat nisl eget, pellentesque ipsum. Proin ullamcorper laoreet erat ac convall is. Cras sodales justo sit amet leo pellentesque, non porta mi aliquet. Nulla laoreet et metus a posuere ntege eget ante ferm entum, accumsan odio nec, feugiat sem. Nullam venenatis auctor neque</p>  
    </div>
          <div class="row">
        <h3 class="sm-heading">Pellentesque sed dolor. Aliquam congue fermentum nisl. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pel lentesque vitae turpis tristique, feugiat nisl eget, pellentesque ipsum. Proin ullamcorper laoreet erat ac convall is.</h3>
        <p class="hero-text">Pellentesque sed dolor. Aliquam congue fermentum nisl. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pel lentesque vitae turpis tristique, feugiat nisl eget, pellentesque ipsum. Proin ullamcorper.Pellentesque sed dolor. Aliquam congue fermentum nisl. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pel lentesque vitae turpis tristique, feugiat nisl eget, pellentesque ipsum. Proin ullamcorper laoreet erat ac convall is. Cras sodales justo sit amet leo pellentesque, non porta mi aliquet. Nulla laoreet et metus a posuere ntege eget ante ferm entum, accumsan odio nec, feugiat sem. Nullam venenatis auctor neque</p>  
    </div>
    
    
    <div class="spacer"></div>
</div>
</div>
</div>