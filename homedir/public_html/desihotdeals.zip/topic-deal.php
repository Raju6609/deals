<?php
include('admin/config/connection.php');
$content->get_header();
$getcontent->topic_content();
$content->get_footer();
?>